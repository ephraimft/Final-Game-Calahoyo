
bootGame = {

		create:function(){
				game.physics.startSystem(Phaser.Physics.ARCADE);

				game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    			game.scale.forceLascape = true;
    			game.scale.pageAlignHorizontally = true;
   				game.scale.pageAlignVertically = true;
    			//game.world.setBounds(0,0,800,1200);
			
				game.state.start("preloadGame");
				keyboard = game.input.keyboard.createCursorKeys();
		}
}

preloadGame = {
	preload: function(){

        game.load.image('pik', 'assets/images/1.png');
        game.load.image('about', 'assets/images/about.png');
        game.load.image('play', 'assets/images/PlayBtn.png');
        game.load.image('complete', 'assets/images/complete.png');
        game.load.image('home', 'assets/images/home.png');
		game.load.image('Holen', 'assets/images/Holen.png');
    	game.load.image('Holen1', 'assets/images/Holen1.png');
    	game.load.image('Holen2', 'assets/images/Holen2.png');
    	game.load.image('Holen3', 'assets/images/Holen3.png');
    	game.load.image('Holen4', 'assets/images/Holen4.png');
    	game.load.image('Holen5', 'assets/images/Holen5.png');
    	game.load.image('Holen6', 'assets/images/Holen6.png');
    	game.load.image('butas', 'assets/images/hole.png');
    	game.load.image('restart', 'assets/images/restart.png');
        game.load.image('retart', 'assets/images/retart.png');
    	game.load.image('platform', 'assets/images/platform.png');
    	game.load.image('ins', 'assets/images/2.png');
    	game.load.image('insbtn', 'assets/images/ins.png');
    	//game.load.image('lupa', 'assets/images/sky.png');
    	game.load.image('pbg','assets/images/sky.png');
    	game.load.audio('kansyon','audio/bg.mp3');

    	game.load.spritesheet('pauseButton','assets/images/pause2.png',31,33);
    	game.load.spritesheet('UpButton','assets/images/UpBtn.png',89,58);

	},

	create:function(){
		game.state.start("menuGame");
	}
}

menuGame = {
	create:function(){

		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
    	game.scale.forcePortrait = true;
    	game.scale.forceLandscape = false;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

		//game.stage.backgroundColor = "#DCDCDC";
		
		home = game.add.image(0,0,'home');
		home.scale.set(1.4);

		pbtn = game.add.button(w/2,390,"play",this.lundag);
		pbtn.anchor.set(0.5);

		about = game.add.button(w/2,460,"about",this.abawt);
		about.anchor.set(0.5);

		insbtn = game.add.button(w/2,530,"insbtn",this.instruction);
		insbtn.anchor.set(0.5);
		
 

		console.log("current state: menu");

	},
	update:function(){
			// if(keyboard.up.isDown){
			// 	game.state.start("playGame");
			// }
	},
	lundag:function (){
		game.state.start("playGame");
   },
   abawt: function(){
            about=game.add.image(0,0,"pik");
            about.scale.set(1.4);
            restartButton=game.add.button(w/2,550,"restart",restartB,this);
            restartButton.scale.set(0.5);

             function restartB() {
        	about.visible =! restartButton.visible;
        	restartButton.destroy();


       		 // window.location.href=window.location.href;

       		 game.state.start("menuGame");
            }
	
        },
        instruction:function (){
		instruc=game.add.image(0,0,"ins");
		instruc.scale.set(1.4);
            restartButton=game.add.button(20,100,"restart",restartB,this);
            restartButton.scale.set(0.5);

             function restartB() {
        	about.visible =! restartButton.visible;
        	restartButton.destroy();


       		 // window.location.href=window.location.href;

       		 game.state.start("menuGame");
            }
   },
};


playGame = {
// 	createFlags:function (time){
//     setInterval(function(){
//         for (var r = 0; r < 3; r++)
//     {
//         var Holen5s = Holen5.create(game.world.randomX, game.world.randomY, 'Holen5');
//         Holen5 = Holen5;
//         Holen5.body.collideWorldBounds = true;
//     }
//     },5000);
// },

	create: function(){
		//game.world.setBounds(-1000, -1000, 2000, 2000);
		game.scale.scaleMode = Phaser.ScaleManager.EXACT_FIT;
 
    	game.scale.forcePortrait = false;
    	game.scale.forceLandscape = true;
    	game.scale.pageAlignVertically = true;
		game.scale.pageAlignHorizontally = true;
		game.scale.setScreenSize = true;
		game.scale.refresh();

		bg = game.add.image(0,0,'pbg')
		// as = game.add.sprite(0,0,'pbg');
  //   	as.scale.x = 0.7;
  //   	as.scale.y = 0.4;

		// land = game.add.tileSprite(0, 0, 620, 400, 'lupa');
  //   	land.fixedToCamera = true;

		cursors = game.input.keyboard.createCursorKeys();

		// Holen5 = game.add.group();

		// this.createFlags(1);
		// Holen5.enableBody = true;
		// Holen5.anchor.set(0.5);
		// Holen5.scale.x = sukat;
		// Holen5.scale.y = sukat;

		butaw = game.add.sprite(200,100,'butas');
        game.physics.arcade.enable(butaw);
        butaw.body.velocity.x = 250;
        butaw.anchor.setTo(0.5, 0.5);
        butaw.body.movable  = true;
        butaw.scale.set(0.6,0.6);
        butaw.body.collideWorldBounds = true;

		taya = game.add.sprite(200, 500, 'Holen');
		//game.physics.arcade.enable(taya);
		game.physics.arcade.enable(taya);
		//taya.enableBody = true;
		taya.anchor.set(0.5);
    	taya.scale.x = 0.6;
		taya.scale.y = 0.6;
    	//taya.body.immovable = false;
    	
    	
   		//taya.body.bounce.setTo(1, 1);
   		//taya.angle = game.rnd.angle();
   		kansyon =game.add.audio("kansyon",1,true);
        kansyon.Loop =true;
        kansyon.play();

        restartButton=game.add.button(0,70,"restart",restartB,this);
            restartButton.scale.set(0.2);

             function restartB() {
        	//about.visible =! restartButton.visible;
        	restartButton.destroy();



       		 game.state.start("menuGame");
            }
	
   		
    	// taya.body.drag.set(0.2);
    	//taya.body.maxVelocity.setTo(400, 400);
    	taya.body.collideWorldBounds = true;
    	//sTaya.body.setCircle(60);
    	//taya.fixedToCamera = true;
    	// game.camera.follow(taya);
    	// game.camera.deadzone = new Phaser.Rectangle(100, 100, 100, 100);
    	// game.camera.focusOnXY(0, 0);
   		
    	platform1 = game.add.sprite(0, 10, 'platform');
		//game.physics.enable(platform1, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(platform1);
		platform1.body.immovable = true;
		platform1.enableBody = true;
		//platform1.anchor.setTo(0.5, 0.5);
		platform1.scale.x = 0.3;
		platform1.scale.y = 0.5;
		//platform1.body.velocity = 100;

		platform2 = game.add.sprite(388, 10, 'platform');
		//game.physics.enable(platform2, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(platform2);
		platform2.body.immovable = true;
		platform2.enableBody = true;
		//platform2.anchor.setTo(0.5, 0.5);
		platform2.scale.x = 0.3;
		platform2.scale.y = 0.5;
		//platform2.body.velocity = 100;

		kalaro1 = game.add.sprite(100, 300, 'Holen1');
		//game.physics.enable(kalaro1, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(kalaro1);
		kalaro1.enableBody = true;
		kalaro1.anchor.setTo(0.5, 0.5);
		kalaro1.scale.x = sukat;
		kalaro1.scale.y = sukat;
		kalaro1.angle += 65;
		kalaro1.body.bounce.setTo(1, 1);
		kalaro1.body.collideWorldBounds = true;
		//kalaro1.body.velocity = 100;
		Kalaro2 = game.add.sprite(50, 370, 'Holen2');
		//game.physics.enable(Kalaro2, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(Kalaro2);
		Kalaro2.enableBody = true;
		Kalaro2.anchor.setTo(0.5, 0.5);
		Kalaro2.scale.x = sukat;
		Kalaro2.scale.y = sukat;
		Kalaro2.angle += 140;
		Kalaro2.body.bounce.setTo(1, 1);
		Kalaro2.body.collideWorldBounds = true;
		//Kalaro2.body.velocity = currentSpeed;
		Kalaro3 = game.add.sprite(300, 350, 'Holen3');
		//game.physics.enable(Kalaro3, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(Kalaro3);
		Kalaro3.enableBody = true;
		Kalaro3.anchor.setTo(0.5, 0.5);
		Kalaro3.scale.x = sukat;
		Kalaro3.scale.y = sukat;
		Kalaro3.angle += 220;
		Kalaro3.body.bounce.setTo(1, 1);
		Kalaro3.body.collideWorldBounds = true;
		//Kalaro3.body.velocity = 100;
		Kalaro4 = game.add.sprite(230, 160, 'Holen4');
		//game.physics.enable(Kalaro4, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(Kalaro4);
		Kalaro4.enableBody = true;
		Kalaro4.anchor.setTo(0.5, 0.5);
		Kalaro4.scale.x = sukat;
		Kalaro4.scale.y = sukat;
		Kalaro4.angle += 295;
		Kalaro4.body.bounce.setTo(1, 1);
		Kalaro4.body.collideWorldBounds = true;
		//Kalaro4.body.velocity = 100;
		Kalaro5 = game.add.sprite(210, 200, 'Holen5');
		//game.physics.enable(Kalaro5, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(Kalaro5);
		Kalaro5.enableBody = true;
		Kalaro5.anchor.setTo(0.5, 0.5);
		Kalaro5.scale.x = sukat;
		Kalaro5.scale.y = sukat;
		Kalaro5.angle += 0;
		Kalaro5.body.bounce.setTo(1, 1);
		Kalaro5.body.collideWorldBounds = true;
		//Kalaro5.body.velocity = 100;
		Kalaro6 = game.add.sprite(130, 180, 'Holen6');
		//game.physics.enable(Kalaro5, Phaser.Physics.ARCADE);
		game.physics.arcade.enable(Kalaro6);
		Kalaro6.enableBody = true;
		Kalaro6.anchor.setTo(0.5, 0.5);
		Kalaro6.scale.x = sukat;
		Kalaro6.scale.y = sukat;
		Kalaro6.angle += 0;
		Kalaro6.body.bounce.setTo(1, 1);
		Kalaro6.body.collideWorldBounds = true;
		//Kalaro6.body.velocity = 100;

	upbtn = game.add.button(200, 520, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    upbtn.fixedToCamera = true;  //our buttons should stay on the same place
    upbtn.scale.set(0.7); 
    upbtn.anchor.set(0.5);
    upbtn.events.onInputOver.add(function(){abante=true;});
    upbtn.events.onInputOut.add(function(){abante=false;});
    upbtn.events.onInputDown.add(function(){abante=true;});
    upbtn.events.onInputUp.add(function(){abante=false;});

    downbtn = game.add.button(200, 580, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    downbtn.fixedToCamera = true;  //our buttons should stay on the same place 
    downbtn.angle = 180; 
    downbtn.scale.set(0.7); 
    downbtn.anchor.set(0.5);
    downbtn.events.onInputOver.add(function(){atras=true;});
    downbtn.events.onInputOut.add(function(){atras=false;});
    downbtn.events.onInputDown.add(function(){atras=true;});
    downbtn.events.onInputUp.add(function(){atras=false;});

    kananbtn = game.add.button(350, 550, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kananbtn.angle = 90;
    kananbtn.anchor.setTo(0.5,0.5);
    kananbtn.scale.x = 0.8;
    kananbtn.scale.y = 0.8;
    kananbtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kananbtn.events.onInputOver.add(function(){kanan=true;});
    kananbtn.events.onInputOut.add(function(){kanan=false;});
    kananbtn.events.onInputDown.add(function(){kanan=true;});
    kananbtn.events.onInputUp.add(function(){kanan=false;});

    kaliwabtn = game.add.button(50, 550, 'UpButton', null, this, 0, 1, 0, 1);  //game, x, y, key, callback, callbackContext, overFrame, outFrame, downFrame, upFrame
    kaliwabtn.angle = -90;
    kaliwabtn.anchor.setTo(0.5,0.5);
    kaliwabtn.scale.x = 0.8;
    kaliwabtn.scale.y = 0.8;
    kaliwabtn.fixedToCamera = true;  //our buttons should stay on the same place  
    kaliwabtn.events.onInputOver.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputOut.add(function(){kaliwa=false;});
    kaliwabtn.events.onInputDown.add(function(){kaliwa=true;});
    kaliwabtn.events.onInputUp.add(function(){kaliwa=false;});

    current_score_text = game.add.text(200, 200, '', { font: 'Arial', fontSize: '50px', fill: '#000', align: 'center' }); // 300, 500
	current_score_text.anchor.set(0.5, 0.5);  
    labelhi = game.add.text(340, 40, "HI: " +this.getScore(),{font: '15px Arial', fill: '#ffffff'}); 

		// upbtn = game.add.button(500,330,"UpButton",this.lundag);
		// upbtn.fixedToCamera = true;
  //   	upbtn.scale.x = 0.7;
  //   	upbtn.scale.y = 0.7;

		this.pauseButton = this.game.add.sprite(10, 20, 'pauseButton');
		//this.pauseButton.fixedToCamera = true;
    	this.pauseButton.scale.x = 0.8;
    	this.pauseButton.scale.y = 0.8;
		this.pauseButton.inputEnabled = true;
		this.pauseButton.events.onInputUp.add(function () {
    	this.game.paused = true;
    	var style = {font:'30px Times New Roman',fill : 'white'};
    	this.text = game.add.text(w/2,h/2, "Game is Paused", style);
    	this.text.fixedToCamera = true;
    	this.text.anchor.set(0.5, 0.5);
		}, this);
			game.input.onDown.add(function () {
    	if (this.game.paused) {
        	this.game.paused = false;
        	this.text.destroy();
    }       
}, this);

	},
	update: function(){
		//game.physics.arcade.overlap(taya,kalaro1,Kalaro2,Kalaro3,Kalaro4,Kalaro5);
		game.physics.arcade.collide(taya,kalaro1);
		game.physics.arcade.collide(taya,Kalaro2);
		game.physics.arcade.collide(taya,Kalaro3);
		game.physics.arcade.collide(taya,Kalaro4);
		game.physics.arcade.collide(taya,Kalaro5);
		game.physics.arcade.collide(taya,Kalaro6);
		game.physics.arcade.collide(kalaro1,Kalaro2);
		game.physics.arcade.collide(kalaro1,Kalaro3);
		game.physics.arcade.collide(kalaro1,Kalaro4);
		game.physics.arcade.collide(kalaro1,Kalaro5);
		game.physics.arcade.collide(kalaro1,Kalaro6);
		game.physics.arcade.collide(Kalaro2,Kalaro3);
		game.physics.arcade.collide(Kalaro2,Kalaro4);
		game.physics.arcade.collide(Kalaro2,Kalaro5);
		game.physics.arcade.collide(Kalaro2,Kalaro6);
		game.physics.arcade.collide(Kalaro3,Kalaro4);
		game.physics.arcade.collide(Kalaro3,Kalaro5);
		game.physics.arcade.collide(Kalaro3,Kalaro6);
		game.physics.arcade.collide(Kalaro4,Kalaro5);
		game.physics.arcade.collide(Kalaro4,Kalaro6);
		game.physics.arcade.collide(Kalaro5,Kalaro6);
		game.physics.arcade.overlap(butaw,kalaro1,this.ScoreNa1);
		game.physics.arcade.overlap(butaw,Kalaro2,this.ScoreNa2);
		game.physics.arcade.overlap(butaw,Kalaro3,this.ScoreNa3);
		game.physics.arcade.overlap(butaw,Kalaro4,this.ScoreNa4);
		game.physics.arcade.overlap(butaw,Kalaro5,this.ScoreNa5);
		game.physics.arcade.overlap(butaw,Kalaro6,this.ScoreNa6);
		game.physics.arcade.overlap(butaw,taya,this.ResetGame);
		game.physics.arcade.overlap(butaw,platform1,this.boundsNow);
		game.physics.arcade.overlap(butaw,platform2,this.boundsNoww);


		// game.physics.arcade.overlap(taya,kalaro1,this.ResetGame);
		// game.physics.arcade.overlap(taya,Kalaro2,this.ResetGame);
		// game.physics.arcade.overlap(taya,Kalaro3,this.ResetGame);
		// game.physics.arcade.overlap(taya,Kalaro4,this.ResetGame);
		// game.physics.arcade.overlap(taya,Kalaro5,this.ResetGame);

		//game.physics.arcade.collide(Kalaro5,kalaro1);
			//if (abante){ this.abanteNa(); taya.loadTexture('taya' );}
	taya.body.velocity.x = 0;
	taya.body.velocity.y = 0;
	
	if (butaw.body.collideWorldBounds = true){
		butaw.body.bounce.setTo(1, 1); 
	}
if (abante && !nextAbante) {
       
        taya.body.velocity.y = -100;

    }
     else if (atras && !nextAbante) {
       
        taya.angle +=4;
        taya.body.velocity.y = 100;

    }
    else if (kanan && !nextAbante) {
       
        taya.angle +=4;
        taya.body.velocity.x = 100;

    }
    else if (kaliwa && !nextAbante) {
       
        taya.angle -= 4;
        taya.body.velocity.x = -100;


    }

    //     if (cursors.left.isDown)
    // {
    //     taya.angle -= 4;
    // }
    // else if (cursors.right.isDown)
    // {
    //     taya.angle += 4;
    // }

    // if (cursors.up.isDown)
    // {
    //     //  The speed we'll travel at
    //     currentSpeed = 100;
    // }
    // else
    // {
    //     if (currentSpeed > 0)
    //     {
    //         currentSpeed -= 4;
    //     }
    // }

    // if (currentSpeed > 0)
    // {
    //     game.physics.arcade.velocityFromRotation(taya.rotation, currentSpeed,taya.body.velocity);
    // }
		// land.tilePosition.x = -game.camera.x;
  //   	land.tilePosition.y = -game.camera.y;
	},
	ResetGame: function(){
	//game._paused = true
	game.add.sprite(0,0,'pbg');
	taya.kill();
	this.Over = game.add.text(200,300, '0', {font: '30px Arial', fill: '#ffffff'});
	this.Over.text = 'Game Over';
	this.Over.anchor.setTo(0.5,0.5);
	kansyon.stop();
    restartButton=game.add.button(200,450,"retart",restartB,this);
    restartButton.scale.set(0.6);
    restartButton.anchor.set(0.5);
        function restartB() {
        //gamepage.visible =! restartButton.visible;
        //restartButton.destroy();

        window.location.href=window.location.href;
            }
	
	},

	// restart:function (){
	// window.location.href=window.location.href;
	// stateText.visible = false;
	// },
	ScoreNa1:function(){
		kalaro1.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	ScoreNa2:function(){
		Kalaro2.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	ScoreNa3:function(){
		Kalaro3.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	ScoreNa4:function(){
		Kalaro4.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	ScoreNa5:function(){
		Kalaro5.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	ScoreNa6:function(){
		Kalaro6.kill();
	puntos += 1;
			current_score_text.text = puntos;
	// 		if (this.getScore()<=puntos){
	// 			this.saveScore(puntos);
	// 			labelhi.text = "HI: "+puntos;
	// }
	},
	boundsNow:function(){
		butaw.body.velocity.x = 250;
	},
	boundsNoww:function(){
		butaw.body.velocity.x = -250;
	},
	// OverNa:function(){
	// 	this.Over = game.add.text(170,100, '0', {font: '30px Arial', fill: '#ffffff'});
	// 	this.Over.text = 'Game Over';

 //    stateText = game.add.text(248,170,'',{font:'18px Times New Roman',fill:'white'});
	// stateText.anchor.setTo(0.5,0.5);
	// stateText.visible = false;
 //    stateText.text="Double Tap to Restart";
	// stateText.visible = true;
	// game.input.onTap.addOnce(this.restart,this);
	// game._paused = true
	// },
		 saveScore:function(score){
    localStorage.setItem("indexData",score);
},

 getScore:function(){
    return (localStorage.getItem("indexData") == null || localStorage.getItem("indexData") == "")?0:
    localStorage.getItem("indexData");
},
// 	abanteNa:function (){  //jump with small delay
//     if (game.time.now > nextAbante ){
//        currentSpeed = 100;
//         nextAbante = game.time.now + 900;
//     }
// }
	// lundag:function (){
	// upbtn.frame = 1;
	// // if (p.body.touching.down){
	// // 		p.animations.play('jump');
	// 		currentSpeed = 100;
		
 //   },
 	loopAudio:function(time){
    setInterval(function(){
        kansyon.play();
    },time)
	}
};		

loseGame = {
	preload:function(){

	},
	create:function(){
		
	},
	update:function(){

	}
	
}

winGame = {
	preload:function(){

	},
	create:function(){

	},
	update:function(){

	}
	
}